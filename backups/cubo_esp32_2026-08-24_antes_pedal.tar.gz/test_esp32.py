"""Monitor das seis faces do cubo ESP32 via Wi-Fi UDP ou USB Serial."""

import glob
import socket
import time

import serial

from cube_controller import CUBE_FACE_POWERS, CubeOrientationInterpreter


def _abrir_udp():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.bind(("", 4210))
        sock.settimeout(0.1)
        return sock
    except OSError as exc:
        print(f"[Aviso UDP] {exc}")
        sock.close()
        return None


def _abrir_serial():
    try:
        for device in glob.glob("/dev/cu.*"):
            device_lower = device.lower()
            identifiers = (
                "esp32", "cow", "usbserial", "wchusbserial",
                "slab_usbtouart", "usbmodem", "cp210", "ch340",
            )
            if any(identifier in device_lower for identifier in identifiers):
                return serial.Serial(device, 115200, timeout=0.1)
    except (OSError, serial.SerialException):
        pass
    return None


def monitor():
    print("========================================================================")
    print("  TESTE DO CUBO ESP32 / MPU6050 - SEIS FACES")
    print("========================================================================")
    print("Conecte o Mac a ESP32_COW_GAME (senha 12345678) ou use o cabo USB.")
    print("Gire o modulo e mantenha cada lado parado por aproximadamente 0,5 s.\n")

    sock = _abrir_udp()
    ser = _abrir_serial()
    interpreter = CubeOrientationInterpreter()
    last_status = None
    last_status_time = 0.0

    try:
        while True:
            line = None
            source = ""

            if sock:
                try:
                    data, address = sock.recvfrom(1024)
                    line = data.decode("utf-8", errors="ignore").strip()
                    source = f"Wi-Fi {address[0]}"
                except (socket.timeout, BlockingIOError):
                    pass

            if not line and ser:
                try:
                    line = ser.readline().decode("utf-8", errors="ignore").strip()
                    if line:
                        source = "USB Serial"
                except (OSError, serial.SerialException):
                    pass

            if not line:
                time.sleep(0.01)
                continue

            try:
                values = [float(part.strip()) for part in line.split(",")]
            except ValueError:
                continue
            if len(values) < 3:
                continue

            ax, ay, az = values[:3]
            confirmed_face = interpreter.update(ax, ay, az)
            if confirmed_face:
                power = CUBE_FACE_POWERS[confirmed_face]
                print(
                    f"\n[CONFIRMADO] {confirmed_face} -> {power['name']}"
                    f" ({power['description']})"
                )

            candidate = interpreter.candidate_face or "movendo"
            status = (
                candidate,
                int(interpreter.stability_progress * 4),
                interpreter.stable_face,
            )
            now = time.monotonic()
            if status != last_status or now - last_status_time >= 0.5:
                progress = int(interpreter.stability_progress * 100)
                stable = interpreter.stable_face or "nenhuma"
                print(
                    f"{source:<20} X={ax:+.3f} Y={ay:+.3f} Z={az:+.3f} "
                    f"| candidata={candidate:<8} {progress:3d}% "
                    f"| face={stable}"
                )
                last_status = status
                last_status_time = now
    except KeyboardInterrupt:
        print("\nMonitor encerrado.")
    finally:
        if sock:
            sock.close()
        if ser:
            ser.close()


if __name__ == "__main__":
    monitor()
