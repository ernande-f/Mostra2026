import os
import json
import tempfile
import unittest

from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

import main


class GameplayVisualAndCollisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.init()
        pygame.display.set_mode((320, 180))
        cls.walk_frames, cls.crouch_frames = main.carregar_sprites_vaca()
        cls.assets = main.carregar_assets_obstaculos()
        cls.base_progress = main.PROGRESSO_PLANO_VACA

    @classmethod
    def tearDownClass(cls):
        pygame.quit()

    def obstacle(self, kind, lane=1):
        return {
            "tipo": kind,
            "lane_idx": lane,
            "lane": main.LANE_RATIOS[lane],
            "progresso_y": self.base_progress,
            "velocidade": 0.0,
        }

    def cow(self, lane=1):
        cow = main.VacaPlayer(self.walk_frames, self.crouch_frames)
        cow.current_lane = lane
        cow.target_x = cow._calcular_x_da_faixa(lane)
        cow.x = cow.target_x
        return cow

    def test_generated_obstacle_assets_have_real_alpha_and_content(self):
        for image in self.assets.values():
            self.assertTrue(image.get_flags() & pygame.SRCALPHA)
            self.assertGreater(image.get_bounding_rect(min_alpha=10).width, 100)
            self.assertGreater(image.get_bounding_rect(min_alpha=10).height, 100)

    def test_crouched_sprite_is_visibly_lower_than_standing_sprite(self):
        self.assertLess(
            self.crouch_frames[0].get_height(),
            self.walk_frames[0].get_height() * 0.70,
        )

    def test_ground_crate_hits_standing_or_crouched_cow_in_same_lane(self):
        cow = self.cow()
        crate = self.obstacle("chao")
        self.assertTrue(cow.get_hitbox().colliderect(main.calcular_hitbox_obstaculo(crate)))

        cow.is_crouching = True
        self.assertTrue(cow.get_hitbox().colliderect(main.calcular_hitbox_obstaculo(crate)))

    def test_jump_clears_ground_crate(self):
        cow = self.cow()
        controller = main.InputController()
        controller.trigger_jump("teste")
        for _ in range(8):
            cow.update(controller)
        self.assertFalse(cow.get_hitbox().colliderect(
            main.calcular_hitbox_obstaculo(self.obstacle("chao"))
        ))

    def test_crouch_clears_high_gate_but_standing_cow_hits_beam(self):
        cow = self.cow()
        gate_hitbox = main.calcular_hitbox_obstaculo(self.obstacle("alto"))
        self.assertTrue(cow.get_hitbox().colliderect(gate_hitbox))

        cow.is_crouching = True
        self.assertFalse(cow.get_hitbox().colliderect(gate_hitbox))

    def test_full_obstacle_requires_changing_lane(self):
        obstacle_hitbox = main.calcular_hitbox_obstaculo(self.obstacle("bloqueio"))

        standing_cow = self.cow()
        self.assertTrue(standing_cow.get_hitbox().colliderect(obstacle_hitbox))

        crouched_cow = self.cow()
        crouched_cow.is_crouching = True
        self.assertTrue(crouched_cow.get_hitbox().colliderect(obstacle_hitbox))

        jumping_cow = self.cow()
        jumping_cow.is_jumping = True
        jumping_cow.jump_y = -180.0
        self.assertTrue(jumping_cow.get_hitbox().colliderect(obstacle_hitbox))

    def test_other_lane_does_not_collide(self):
        cow = self.cow(lane=0)
        for kind in ("chao", "alto", "bloqueio"):
            self.assertFalse(cow.get_hitbox().colliderect(
                main.calcular_hitbox_obstaculo(self.obstacle(kind, lane=2))
            ))

    def test_obstacle_is_born_at_the_beginning_of_the_rings(self):
        obstacle = main.criar_obstaculo()
        self.assertEqual(obstacle["progresso_y"], main.PROGRESSO_SPAWN)
        _, y, _ = main.calcular_posicao_pista(obstacle["progresso_y"], obstacle["lane"])
        self.assertLess(y, main.HORIZON_Y)
        self.assertEqual(main.PROGRESSO_MINIMO_VISIVEL, main.PROGRESSO_SPAWN)

    def test_saturn_video_is_available_as_animated_game_background(self):
        fallback = pygame.Surface((main.LARGURA_VIRTUAL, main.ALTURA_VIRTUAL))
        background = main.FundoJogoAnimado(
            main.VIDEO_FUNDO_JOGO,
            fallback,
            (main.LARGURA_VIRTUAL, main.ALTURA_VIRTUAL),
        )
        try:
            self.assertTrue(background.video_ativo)
            self.assertEqual(
                background.frame_atual.get_size(),
                (main.LARGURA_VIRTUAL, main.ALTURA_VIRTUAL),
            )
        finally:
            background.close()

    def test_only_easy_mode_is_available(self):
        self.assertEqual(tuple(main.DIFICULDADES), (main.MODO_JOGO,))
        with patch("main.random.uniform", return_value=0.012):
            easy = main.criar_obstaculo(main.DIFICULDADES["FACIL"]["velocidade"])
        self.assertAlmostEqual(easy["velocidade"], 0.012 * 0.78)

    def test_lane_routes_follow_the_three_bands_in_the_background(self):
        samples = (
            (240, (637, 715, 803)),
            (380, (749, 848, 958)),
            (580, (765, 924, 1067)),
            (700, (725, 924, 1082)),
        )
        alcance_vertical = main.BASE_Y - main.HORIZON_Y + 120
        for y, expected_xs in samples:
            progress = (y - main.HORIZON_Y) / alcance_vertical
            actual_xs = [
                main.calcular_posicao_pista(progress, lane)[0]
                for lane in main.LANE_RATIOS
            ]
            for actual, expected in zip(actual_xs, expected_xs):
                self.assertAlmostEqual(actual, expected, delta=2.0)

    def test_cow_uses_the_same_lane_centers_as_obstacles(self):
        for lane_index, lane_ratio in enumerate(main.LANE_RATIOS):
            cow = self.cow(lane=lane_index)
            cow_center = cow.x + main.LARGURA_VACA_NORMAL / 2
            route_center = main.calcular_posicao_pista(
                main.PROGRESSO_PLANO_VACA,
                lane_ratio,
            )[0]
            self.assertAlmostEqual(cow_center, route_center)

    def test_obstacle_scale_stops_growing_near_the_end_of_lane(self):
        size_at_cap = main.calcular_posicao_pista(0.92)[2]
        self.assertEqual(main.calcular_posicao_pista(1.00)[2], size_at_cap)
        self.assertEqual(main.calcular_posicao_pista(1.20)[2], size_at_cap)

    def test_cube_interpreter_recognizes_all_six_faces(self):
        vectors = {
            "+X": (1.0, 0.0, 0.0),
            "-X": (-1.0, 0.0, 0.0),
            "+Y": (0.0, 1.0, 0.0),
            "-Y": (0.0, -1.0, 0.0),
            "+Z": (0.0, 0.0, 1.0),
            "-Z": (0.0, 0.0, -1.0),
        }
        for expected_face, vector in vectors.items():
            interpreter = main.CubeOrientationInterpreter(stable_seconds=0.45)
            self.assertIsNone(interpreter.update(*vector, now=0.0))
            self.assertIsNone(interpreter.update(*vector, now=0.2))
            self.assertEqual(interpreter.update(*vector, now=0.5), expected_face)

    def test_cube_rejects_diagonal_or_moving_orientation(self):
        interpreter = main.CubeOrientationInterpreter(stable_seconds=0.45)
        for now in (0.0, 0.3, 0.7):
            self.assertIsNone(interpreter.update(0.70, 0.70, 0.0, now=now))
        self.assertIsNone(interpreter.stable_face)

    def test_esp32_cube_does_not_move_jump_or_crouch_the_cow(self):
        controller = main.InputController()
        controller._process_sensor_line("1.00,0.00,0.00", "TESTE", now=0.0)
        controller._process_sensor_line("1.00,0.00,0.00", "TESTE", now=0.5)

        target, shift = controller.consume_lane_commands()
        self.assertIsNone(target)
        self.assertEqual(shift, 0)
        self.assertFalse(controller.consume_jump())
        self.assertFalse(controller.is_crouching)
        self.assertEqual(controller.consume_cube_power(), "+X")

    def test_cube_only_arms_after_five_obstacles(self):
        powers = main.CubePowerSystem(required_obstacles=5)
        for index in range(4):
            self.assertFalse(powers.register_obstacle_passed(now=float(index)))
        self.assertFalse(powers.armed)
        self.assertEqual(powers.charge_ratio, 0.8)

        self.assertTrue(powers.register_obstacle_passed(now=4.0))
        self.assertTrue(powers.armed)
        self.assertEqual(powers.charge_ratio, 1.0)

        activation = powers.activate_face("+X", now=5.0)
        self.assertTrue(activation.accepted)
        self.assertFalse(powers.armed)
        self.assertEqual(powers.charge, 0)

    def test_cube_power_system_applies_buffs_debuffs_and_chaos(self):
        powers = main.CubePowerSystem(required_obstacles=1)

        powers.register_obstacle_passed(now=9.0)
        shield = powers.activate_face("+X", now=10.0)
        self.assertTrue(shield.accepted)
        self.assertTrue(powers.absorb_collision(now=10.1))
        self.assertFalse(powers.absorb_collision(now=10.2))

        powers.register_obstacle_passed(now=19.0)
        powers.activate_face("-X", now=20.0)
        self.assertEqual(powers.obstacle_speed_multiplier(now=21.0), 0.55)
        self.assertEqual(powers.obstacle_speed_multiplier(now=26.0), 1.0)

        powers.register_obstacle_passed(now=29.0)
        powers.activate_face("-Y", now=30.0)
        self.assertEqual(powers.obstacle_speed_multiplier(now=31.0), 1.65)
        self.assertEqual(powers.obstacle_speed_multiplier(now=36.0), 1.0)

        powers.register_obstacle_passed(now=39.0)
        clear = powers.activate_face("+Y", now=40.0)
        self.assertTrue(clear.clear_track)

        powers.register_obstacle_passed(now=49.0)
        powers.activate_face("+Z", now=50.0)
        self.assertEqual(powers.spawn_interval_multiplier(now=51.0), 0.52)
        self.assertEqual(powers.spawn_interval_multiplier(now=58.0), 1.0)

        powers.register_obstacle_passed(now=59.0)
        powers.activate_face("-Z", now=60.0)
        self.assertEqual(powers.score_multiplier(now=61.0), 2.0)
        self.assertEqual(powers.obstacle_speed_multiplier(now=61.0), 1.35)
        self.assertEqual(powers.score_multiplier(now=69.0), 1.0)

    def test_persistent_ranking_keeps_only_top_five(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "ranking.json"
            ranking = main.RankingPersistente(path)
            for name, score in (("Ana", 20), ("Bia", 50), ("Caio", 10), ("Duda", 90), ("Eva", 40), ("Fê", 70)):
                ranking.registrar(name, score, main.MODO_JOGO)

            reloaded = main.RankingPersistente(path)
            self.assertEqual([item["pontos"] for item in reloaded.entradas], [90, 70, 50, 40, 20])
            self.assertEqual(reloaded.entradas[1]["nome"], "FÊ")
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))[0]["nome"], "DUDA")

    def test_corrupt_ranking_file_does_not_break_game(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "ranking.json"
            path.write_text("nao e json", encoding="utf-8")
            self.assertEqual(main.RankingPersistente(path).entradas, [])


if __name__ == "__main__":
    unittest.main()
