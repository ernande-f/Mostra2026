# Cow Abduct com visão computacional e cubo ESP32

O jogo usa **OpenCV + MediaPipe Pose** para transformar o movimento do corpo em comandos da vaquinha. A câmera é processada em uma thread separada, portanto não reduz o FPS do loop principal. Se o MediaPipe não puder iniciar no Mac, há um fallback por detecção facial do OpenCV.

## Como abrir no macOS

1. Na primeira vez, dê dois cliques em `instalar_dependencias.command`.
2. Depois, dê dois cliques em `jogar.command`.
3. Quando o macOS perguntar, permita o acesso do Python/Terminal à câmera.
4. Fique no centro e em pé durante a calibração inicial (cerca de 1–2 segundos).

Se a câmera já tiver sido negada, abra **Ajustes do Sistema → Privacidade e Segurança → Câmera** e habilite o Terminal ou o Codex (o aplicativo a partir do qual o jogo for executado).

O projeto usa Python 3.12 porque essa é a versão compatível com o MediaPipe usado pelo jogo. O Python 3.14 global não deve ser usado para executá-lo.

## Controles corporais

- Mover o tronco para a esquerda/direita: troca entre as três faixas.
- Subir o corpo: pula.
- Baixar/agachar o corpo: agacha a vaquinha.
- `C`: recalibra a posição neutra da câmera.
- `V`: mostra/oculta a câmera dentro do jogo.
- `Tab`: mostra/oculta a telemetria.

O teclado continua disponível: `A/D` ou setas para as faixas, `W`, seta para cima ou espaço para pular, `S`, seta para baixo ou Shift para agachar.

## Cubo ESP32/MPU6050

O ESP32 não movimenta mais a vaca. Cada obstáculo superado carrega 20% da energia; depois de cinco obstáculos, o painel exibe **CUBO PRONTO**. Nesse momento, gire o cubo para uma nova face e deixe-o parado por aproximadamente meio segundo. O resultado pode ajudar ou atrapalhar:

- `+X`: escudo por até 12 segundos ou até bloquear uma colisão.
- `-X`: câmera lenta por 5 segundos.
- `+Y`: explosão que limpa a pista.
- `-Y`: hipervelocidade dos obstáculos por 5 segundos (debuff).
- `+Z`: tempestade com obstáculos mais frequentes por 7 segundos (debuff).
- `-Z`: modo caos com pontos em dobro e velocidade 35% maior por 8 segundos.

O firmware atual em `esp32_sensor/esp32_sensor.ino` já transmite os três eixos necessários. Para validar a orientação sem abrir o jogo, conecte o Mac à rede `ESP32_COW_GAME` e execute:

```bash
.venv/bin/python test_esp32.py
```

No jogo, o painel no canto superior direito mostra a carga, os valores `X/Y/Z`, a face reconhecida e os efeitos ativos. O cubo só aceita uma face quando a barra estiver completa; depois disso, a carga volta a zero.

## Ranking e ritmo de jogo

- Clique em **JOGADOR** no menu para escrever um nome de até 12 caracteres.
- Clique no botão cinza **JOGAR** que faz parte da própria arte do menu, ou pressione espaço, para iniciar.
- O jogo possui apenas o modo **Fácil**, com velocidade e intervalo de obstáculos estáveis durante toda a partida.
- As cinco melhores pontuações ficam salvas em `dados/ranking.json` e reaparecem quando o jogo é aberto novamente.
- Os obstáculos agora entram pela parte superior da pista, antes do horizonte, dando mais tempo para enxergá-los.
- Os novos obstáculos indicam três ações: `ob1` bloqueia a faixa e exige desvio lateral, `ob2` é baixo e exige pulo, e `ob3` deixa uma passagem inferior para agachar.

## Correções visuais

- Durante a partida, `videos/gif_fundo_saturno.mp4` é reproduzido como fundo animado em loop; se o vídeo não puder ser aberto, o jogo usa automaticamente o cenário estático anterior.
- O gameplay agora carrega o cenário completo de Saturno, em vez do fundo vazio de estrelas.
- As rotas usam splines medidas nas quatro bordas principais dos anéis do vídeo, convergindo no horizonte e abrindo em curva até a vaca.
- O crescimento dos obstáculos é limitado perto do fim da lane para que eles não cubram a tela.
- Os sprites `ob1`, `ob2` e `ob3` substituem os obstáculos provisórios e preservam a proporção original durante a aproximação.
- Sprite, hitbox e feixe foram alinhados para o agachamento ficar visualmente justo.
- O menu recebeu medalhas, planetas, estrela e asteroide desenhados em tempo real para identificar ranking e dificuldades.

## Execução pelo terminal

```bash
./instalar_dependencias.command
./jogar.command
```

Para rodar apenas os testes dos gestos:

```bash
.venv/bin/python -m unittest -v test_vision_controller.py test_gameplay.py
```
