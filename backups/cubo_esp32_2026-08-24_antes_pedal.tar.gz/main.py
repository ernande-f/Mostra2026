import pygame
import random
import math
import sys
import threading
import time
import json
import os

from datetime import datetime
from pathlib import Path

from cube_controller import CUBE_FACE_POWERS, CubeOrientationInterpreter, CubePowerSystem
from vision_controller import VisionController

# ==========================================
# CONFIGURAÇÕES GERAIS E RESOLUÇÃO VIRTUAL
# ==========================================
LARGURA_VIRTUAL = 1280
ALTURA_VIRTUAL = 720
FPS = 60
PASTA_PROJETO = Path(__file__).resolve().parent
ARQUIVO_RANKING = PASTA_PROJETO / "dados" / "ranking.json"
VIDEO_FUNDO_JOGO = PASTA_PROJETO / "videos" / "gif_fundo_saturno.mp4"
AREA_BOTAO_JOGAR = (230, 390, 440, 54)

# O jogo usa um unico ritmo facil, sem aceleracao progressiva escondida.
MODO_JOGO = "FACIL"
DIFICULDADES = {
    MODO_JOGO: {
        "nome": "FÁCIL",
        "velocidade": 0.78,
        "spawn": 64,
        "cor": (88, 236, 150),
    },
}

# O obstaculo nasce junto ao inicio visivel dos aneis.
PROGRESSO_SPAWN = -0.04
PROGRESSO_MINIMO_VISIVEL = -0.04

# ==========================================
# CONSTANTES DA PISTA (ANÉIS DE SATURNO - 3 FAIXAS)
# ==========================================
# Os anéis de Saturno ficam na metade direita da imagem
HORIZON_Y = 220
BASE_Y = 580
PROGRESSO_PLANO_VACA = (
    (BASE_Y - HORIZON_Y)
    / (BASE_Y - HORIZON_Y + 120)
)

# Quatro bordas medidas diretamente no frame do vídeo em resolução virtual.
# Cada tupla representa (y, limite esquerdo, divisória 1, divisória 2, direito).
ROTA_ANEIS = (
    (200, 556.0, 628.0, 700.0, 799.0),
    (240, 599.0, 674.5, 756.0, 849.0),
    (280, 642.0, 721.5, 811.5, 898.5),
    (320, 675.0, 752.5, 862.5, 944.5),
    (380, 707.5, 790.5, 906.0, 1010.5),
    (450, 717.5, 827.0, 942.0, 1066.5),
    (520, 707.0, 841.5, 976.5, 1106.0),
    (580, 683.5, 847.0, 1001.5, 1132.0),
    (640, 646.5, 847.5, 1011.5, 1146.5),
    (700, 613.5, 837.0, 1012.0, 1151.5),
    (720, 604.5, 834.5, 1007.0, 1156.5),
)

# Centros das três lanes entre as quatro bordas acima.
LANE_RATIOS = [1 / 6, 1 / 2, 5 / 6]
NUM_LANES = len(LANE_RATIOS)
NOME_LANES = ["ESQUERDA", "CENTRO", "DIREITA"]

# Dimensões da Vaca nos Anéis
LARGURA_VACA_NORMAL = 105
ALTURA_VACA_NORMAL = 135
LARGURA_VACA_AGACHADA = 105
ALTURA_VACA_AGACHADA = 85

# A camera reconhece o abaixar do tronco e mantem a pose enquanto o jogador
# estiver agachado.
ENABLE_CROUCH = True

# Dimensões dos Obstáculos
TAMANHO_OBSTACULO_MIN = 20
TAMANHO_OBSTACULO_MAX = 74


# =========================================================
# RANKING LOCAL PERSISTENTE
# =========================================================
def normalizar_nome_jogador(nome):
    """Limpa o nome exibido e salvo sem impedir letras acentuadas."""
    nome_limpo = "".join(ch for ch in str(nome).strip() if ch.isalnum() or ch in "-_ ")
    return (nome_limpo[:12].strip() or "JOGADOR").upper()


class RankingPersistente:
    """Mantem o top 5 em JSON, inclusive entre execucoes do jogo."""

    def __init__(self, caminho=ARQUIVO_RANKING, limite=5):
        self.caminho = Path(caminho)
        self.limite = limite
        self.entradas = self._carregar()

    def _carregar(self):
        try:
            dados = json.loads(self.caminho.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return []

        if not isinstance(dados, list):
            return []

        entradas_validas = []
        for item in dados:
            if not isinstance(item, dict):
                continue
            try:
                pontos = max(0, int(item.get("pontos", 0)))
            except (TypeError, ValueError):
                continue
            dificuldade = str(item.get("dificuldade", MODO_JOGO)).upper()
            if dificuldade not in DIFICULDADES:
                dificuldade = MODO_JOGO
            entradas_validas.append({
                "nome": normalizar_nome_jogador(item.get("nome", "JOGADOR")),
                "pontos": pontos,
                "dificuldade": dificuldade,
                "data": str(item.get("data", "")),
            })

        entradas_validas.sort(key=lambda item: item["pontos"], reverse=True)
        return entradas_validas[:self.limite]

    def registrar(self, nome, pontos, dificuldade):
        entrada = {
            "nome": normalizar_nome_jogador(nome),
            "pontos": max(0, int(pontos)),
            "dificuldade": dificuldade if dificuldade in DIFICULDADES else MODO_JOGO,
            "data": datetime.now().isoformat(timespec="seconds"),
        }
        candidatas = self.entradas + [entrada]
        candidatas.sort(key=lambda item: item["pontos"], reverse=True)
        self.entradas = candidatas[:self.limite]
        self._salvar()

        # Retorna a colocacao apenas se esta partida permaneceu no top 5.
        for indice, item in enumerate(self.entradas):
            if item is entrada:
                return indice + 1
        return None

    def _salvar(self):
        try:
            self.caminho.parent.mkdir(parents=True, exist_ok=True)
            temporario = self.caminho.with_suffix(self.caminho.suffix + ".tmp")
            temporario.write_text(
                json.dumps(self.entradas, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            os.replace(temporario, self.caminho)
        except OSError as exc:
            # Uma falha de escrita nao pode derrubar a partida.
            print(f"[RANKING] Nao foi possivel salvar {self.caminho}: {exc}")


# =========================================================
# CONTROLADOR DE ENTRADA (CAMERA + TECLADO + CUBO ESP32)
# =========================================================
class InputController:
    """
    A camera/teclado controlam a vaca; o ESP32 reconhece as faces do cubo.
    """
    def __init__(self):
        self.jump_event = False    # True quando detecta impulso de salto
        self.lane_shift_event = 0  # -1 esquerda | +1 direita
        self.target_lane_event = None
        self.is_crouching = False
        self.last_control_source = "teclado"
        self._event_lock = threading.Lock()
        self._crouch_sources = {"keyboard": False, "vision": False}
        self.vision_recalibrate_callback = None

        # Telemetria para Debug
        self.raw_ax = 0.0
        self.raw_ay = 0.0
        self.raw_az = 1.0

        # O modulo mostrado no video ja pode testar as seis orientacoes antes
        # de ser instalado no cubo definitivo impresso em 3D.
        self.cube_interpreter = CubeOrientationInterpreter()
        self.cube_face = None
        self.cube_candidate_face = None
        self.cube_stability = 0.0
        self.cube_power_event = None

        self.active_port_name = "Nenhuma"
        self.show_debug = False    # [TAB] exibe telemetria sem cobrir a pista
        self.show_camera = True    # [V] alterna a pre-visualizacao da webcam

        # Variáveis para integração com ESP32
        self.esp32_connected = False
        self.esp32_thread = None
        self.esp32_running = False
        self.esp32_port = "auto"
        self.esp32_baudrate = 115200

        self.last_packet_time = 0.0
        self.wifi_thread = None

        self.feedback_msg = ""             # Mensagem de notificação na tela
        self.feedback_timer = 0.0          # Timer para apagar a notificação

        # Debounce do teclado
        self.prev_k_up = False
        self.prev_k_left = False
        self.prev_k_right = False
        self.prev_k_c = False

    def trigger_jump(self, source="entrada"):
        """Publica um pulo de forma segura a partir de qualquer thread."""
        with self._event_lock:
            self.jump_event = True
            self.last_control_source = source

    def consume_jump(self):
        with self._event_lock:
            event = self.jump_event
            self.jump_event = False
            return event

    def request_lane_shift(self, direction, source="entrada"):
        with self._event_lock:
            self.lane_shift_event = -1 if direction < 0 else 1
            self.last_control_source = source

    def request_target_lane(self, lane, source="entrada"):
        with self._event_lock:
            self.target_lane_event = max(0, min(NUM_LANES - 1, int(lane)))
            self.last_control_source = source

    def consume_lane_commands(self):
        with self._event_lock:
            target = self.target_lane_event
            shift = self.lane_shift_event
            self.target_lane_event = None
            self.lane_shift_event = 0
            return target, shift

    def consume_cube_power(self):
        """Consome uma unica mudanca de face confirmada pelo MPU6050."""
        with self._event_lock:
            event = self.cube_power_event
            self.cube_power_event = None
            return event

    def set_crouching(self, source, active):
        with self._event_lock:
            self._crouch_sources[source] = bool(active)
            self.is_crouching = any(self._crouch_sources.values()) if ENABLE_CROUCH else False
            if active:
                self.last_control_source = source

    def calibrate_center(self):
        """Solicita uma nova tara da visao; o cubo usa a gravidade absoluta."""
        if self.vision_recalibrate_callback:
            self.vision_recalibrate_callback()
        self.feedback_msg = "● RECALIBRANDO CAMERA..."
        self.feedback_timer = time.time() + 2.5
        print("[CALIBRACAO] Camera recalibrada; o cubo nao precisa de tara")

    def update_from_keyboard(self, keys):
        """Teclado continua disponivel como fallback e para testes."""
        k_up = keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]

        # Pulo no teclado (disparo único por clique)
        if k_up and not self.prev_k_up:
            self.trigger_jump("teclado")
        self.prev_k_up = k_up

        k_left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        k_right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        if k_left and not self.prev_k_left:
            self.request_lane_shift(-1, "teclado")
        elif k_right and not self.prev_k_right:
            self.request_lane_shift(1, "teclado")
        self.prev_k_left = k_left
        self.prev_k_right = k_right

        k_down = keys[pygame.K_DOWN] or keys[pygame.K_s] or keys[pygame.K_LSHIFT]
        self.set_crouching("keyboard", k_down)

        # Tecla [C] para Calibrar Centro da Cintura
        k_c = keys[pygame.K_c]
        if k_c and not self.prev_k_c:
            self.calibrate_center()
        self.prev_k_c = k_c

    def start_esp32_connection(self, port="auto", baudrate=115200):
        """Inicia a escuta sem fio via Wi-Fi UDP e USB Serial simultaneamente."""
        self.esp32_port = port
        self.esp32_baudrate = baudrate
        self.esp32_running = True

        # 1. Thread Wi-Fi UDP (Ultra rápida < 2ms)
        self.wifi_thread = threading.Thread(target=self._wifi_worker, daemon=True)
        self.wifi_thread.start()

        # 2. Thread USB Serial (Fallback)
        self.esp32_thread = threading.Thread(target=self._esp32_worker, daemon=True)
        self.esp32_thread.start()

    def _process_sensor_line(self, linha, source_name="ESP32", now=None):
        """Transforma ``ax,ay,az`` em uma das seis faces do cubo."""
        partes = [p.strip() for p in linha.split(',') if p.strip()]
        if len(partes) >= 1:
            try:
                if len(partes) == 1:
                    az = float(partes[0])
                    ax, ay = 0.0, 0.0
                    pacote_completo = False
                elif len(partes) >= 3:
                    ax = float(partes[0])
                    ay = float(partes[1])
                    az = float(partes[2])
                    pacote_completo = True
                else:
                    az = float(partes[0])
                    ax, ay = 0.0, 0.0
                    pacote_completo = False

                self.raw_ax = ax
                self.raw_ay = ay
                self.raw_az = az

                self.esp32_connected = True
                self.active_port_name = source_name
                self.last_packet_time = time.time()

                if pacote_completo:
                    momento = time.monotonic() if now is None else now
                    nova_face = self.cube_interpreter.update(ax, ay, az, momento)
                    self.cube_face = self.cube_interpreter.stable_face
                    self.cube_candidate_face = self.cube_interpreter.candidate_face
                    self.cube_stability = self.cube_interpreter.stability_progress

                    if nova_face is not None:
                        config = CUBE_FACE_POWERS[nova_face]
                        with self._event_lock:
                            self.cube_power_event = nova_face
                            self.last_control_source = "cubo esp32"
                        self.feedback_msg = f'CUBO {nova_face}: {config["name"]}'
                        self.feedback_timer = time.time() + 2.0
                        print(
                            f'[CUBO] Face {nova_face} confirmada -> {config["name"]}'
                        )

            except ValueError:
                pass

    def _wifi_worker(self):
        """Escuta pacotes de acelerômetro transmitidos via Wi-Fi UDP Broadcast (Porta 4210)."""
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.bind(("", 4210))
            sock.settimeout(0.5)
            print("[WI-FI] Receptor UDP iniciado na porta 4210...")
        except Exception as e:
            print(f"[WI-FI] Aviso: Porta 4210: {e}")
            return

        while self.esp32_running:
            try:
                data, addr = sock.recvfrom(1024)
                if data:
                    linha = data.decode('utf-8', errors='ignore').strip()
                    if linha:
                        self._process_sensor_line(linha, source_name=f"Wi-Fi [{addr[0]}]")
            except socket.timeout:
                if self.active_port_name.startswith("Wi-Fi") and (time.time() - self.last_packet_time > 2.5):
                    self.esp32_connected = False
                    self.active_port_name = "Procurando Wi-Fi..."
                    self.cube_interpreter.reset()
                    self.cube_face = None
                    self.cube_candidate_face = None
                    self.cube_stability = 0.0
            except Exception:
                time.sleep(0.05)

    def _get_candidate_ports(self):
        """Retorna uma lista de portas seriais USB válidas."""
        candidatas = []
        blacklist = ["incoming-port", "wlan-debug", "debug-console", "airpods", "headset", "iphone", "watch", "soc"]

        try:
            import glob
            devs = glob.glob('/dev/cu.*')
            for d in devs:
                d_low = d.lower()
                if any(b in d_low for b in blacklist):
                    continue
                if any(k in d_low for k in ["esp32", "cow", "usbserial", "wchusbserial", "slab_usbtouart", "usbmodem", "cp210", "ch340", "ftdi"]):
                    if d not in candidatas:
                        candidatas.append(d)
        except Exception as e:
            print(f"[DEBUG] Erro scan glob: {e}")

        return candidatas

    def _esp32_worker(self):
        """Thread para conexão com ESP32 via Cabo USB Serial."""
        try:
            import serial
        except ImportError:
            return

        while self.esp32_running:
            if self.esp32_connected and self.active_port_name.startswith("Wi-Fi"):
                time.sleep(1.0)
                continue

            if self.esp32_port and self.esp32_port != "auto":
                portas = [self.esp32_port]
            else:
                portas = self._get_candidate_ports()

            if not portas:
                if not self.esp32_connected:
                    self.active_port_name = "Aguardando Wi-Fi ou USB..."
                time.sleep(1.0)
                continue

            conectado = False
            for target_port in portas:
                if not self.esp32_running or (self.esp32_connected and self.active_port_name.startswith("Wi-Fi")):
                    break
                try:
                    with serial.Serial(target_port, self.esp32_baudrate, timeout=1.0) as ser:
                        while self.esp32_running:
                            if self.esp32_connected and self.active_port_name.startswith("Wi-Fi"):
                                break
                            try:
                                if ser.in_waiting > 120:
                                    ser.reset_input_buffer()
                            except Exception:
                                pass

                            linha = ser.readline().decode('utf-8', errors='ignore').strip()
                            if linha:
                                self._process_sensor_line(linha, source_name=f"USB ({target_port.split('/')[-1]})")
                                conectado = True
                except Exception:
                    continue

            if not conectado and not self.esp32_connected:
                time.sleep(1.0)


# =========================================================
# CARREGAMENTO E ALINHAMENTO PRECISO DOS SPRITES DA VACA
# =========================================================
def carregar_asset(candidatos, com_alpha=False):
    """Busca a imagem entre vários caminhos possíveis para evitar erros de arquivo não encontrado."""
    import os
    for caminho in candidatos:
        if os.path.exists(caminho):
            try:
                img = pygame.image.load(caminho)
                return img.convert_alpha() if com_alpha else img.convert()
            except Exception as e:
                print(f"[DEBUG] Erro ao carregar {caminho}: {e}")
    # Cria uma superfície reserva segura
    surf = pygame.Surface((1280, 720), pygame.SRCALPHA if com_alpha else 0)
    surf.fill((30, 20, 50))
    return surf


class FundoJogoAnimado:
    """Reproduz um MP4 em loop e usa uma imagem estática como reserva."""

    def __init__(self, caminho_video, imagem_fallback, tamanho):
        self.caminho_video = Path(caminho_video)
        self.tamanho = tuple(tamanho)
        self.imagem_fallback = pygame.transform.scale(imagem_fallback, self.tamanho)
        self.frame_atual = self.imagem_fallback
        self.video_ativo = False
        self._capture = None
        self._cv2 = None
        self._intervalo_frame = 1.0 / 30.0
        self._tempo_acumulado = 0.0
        self._ultimo_instante = None
        self._abrir_video()

    def _abrir_video(self):
        if not self.caminho_video.exists():
            print(f"[FUNDO] Vídeo não encontrado: {self.caminho_video}")
            return

        try:
            import cv2

            capture = cv2.VideoCapture(str(self.caminho_video))
            if not capture.isOpened():
                capture.release()
                print(f"[FUNDO] Não foi possível abrir: {self.caminho_video}")
                return

            fps_video = capture.get(cv2.CAP_PROP_FPS)
            if fps_video and math.isfinite(fps_video) and fps_video > 0:
                self._intervalo_frame = 1.0 / fps_video

            self._cv2 = cv2
            self._capture = capture
            self.video_ativo = self._ler_proximo_frame()
            if self.video_ativo:
                print(f"[FUNDO] Vídeo animado carregado: {self.caminho_video.name}")
            else:
                self.close()
        except Exception as exc:
            print(f"[FUNDO] Erro ao carregar vídeo; usando imagem estática: {exc}")
            self.close()

    def _ler_proximo_frame(self):
        if self._capture is None or self._cv2 is None:
            return False

        ok, frame = self._capture.read()
        if not ok:
            # Ao chegar ao final, volta ao primeiro quadro para manter o loop.
            self._capture.set(self._cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = self._capture.read()
        if not ok:
            return False

        interpolacao = (
            self._cv2.INTER_AREA
            if frame.shape[1] >= self.tamanho[0] and frame.shape[0] >= self.tamanho[1]
            else self._cv2.INTER_LINEAR
        )
        frame = self._cv2.resize(frame, self.tamanho, interpolation=interpolacao)
        frame_rgb = self._cv2.cvtColor(frame, self._cv2.COLOR_BGR2RGB)
        self.frame_atual = pygame.image.frombytes(
            frame_rgb.tobytes(),
            self.tamanho,
            "RGB",
        ).convert()
        return True

    def desenhar(self, canvas):
        if self.video_ativo:
            agora = time.monotonic()
            if self._ultimo_instante is None:
                self._ultimo_instante = agora
            decorrido = agora - self._ultimo_instante
            self._ultimo_instante = agora

            # Uma passagem pelo menu não deve provocar uma leitura acelerada
            # de dezenas de quadros quando a partida recomeçar.
            if decorrido <= 0.5:
                self._tempo_acumulado += max(0.0, decorrido)

            quadros_pendentes = int(self._tempo_acumulado / self._intervalo_frame)
            if quadros_pendentes:
                for _ in range(min(quadros_pendentes, 12)):
                    if not self._ler_proximo_frame():
                        self.video_ativo = False
                        self.frame_atual = self.imagem_fallback
                        break
                self._tempo_acumulado %= self._intervalo_frame

        canvas.blit(self.frame_atual, (0, 0))

    def close(self):
        if self._capture is not None:
            self._capture.release()
        self._capture = None
        self.video_ativo = False


def carregar_sprites_vaca():
    """
    Carrega a sprite sheet 'Imagens/sprite1.png' com recorte exato
    das 6 poses, centralizando o centro de massa e alinhando os pés.
    """
    sprite_sheet = carregar_asset(["Imagens/sprite1.png", "sprite1.png"], com_alpha=True)

    boxes_andar = [
        (33, 77, 297, 748),
        (374, 77, 356, 748),
        (720, 77, 292, 748),
    ]
    boxes_agachar = [
        (33, 825, 297, 627),
        (374, 825, 356, 627),
        (720, 825, 292, 627),
    ]

    frames_andar = []
    frames_agachar = []

    for x, y, w, h in boxes_andar:
        sub = sprite_sheet.subsurface(pygame.Rect(x, y, w, h))
        canvas = pygame.Surface((360, 750), pygame.SRCALPHA)
        dest_x = (360 - w) // 2
        dest_y = 750 - h
        canvas.blit(sub, (dest_x, dest_y))
        scaled = pygame.transform.smoothscale(canvas, (LARGURA_VACA_NORMAL, ALTURA_VACA_NORMAL))
        frames_andar.append(scaled)

    for x, y, w, h in boxes_agachar:
        sub = sprite_sheet.subsurface(pygame.Rect(x, y, w, h))
        canvas = pygame.Surface((360, 750), pygame.SRCALPHA)
        dest_x = (360 - w) // 2
        dest_y = 750 - h
        canvas.blit(sub, (dest_x, dest_y))
        # O frame agachado precisa ser realmente baixo; antes ele era escalado
        # quase como a pose em pe e nao correspondia a hitbox reduzida.
        scaled = pygame.transform.smoothscale(canvas, (LARGURA_VACA_AGACHADA, ALTURA_VACA_AGACHADA))
        frames_agachar.append(scaled)

    return frames_andar, frames_agachar


# =========================================================
# FUNÇÕES DE PERSPECTIVA E CURVATURA DOS ANÉIS DE SATURNO
# =========================================================
def _catmull_rom(p0, p1, p2, p3, t):
    """Interpolação suave que atravessa os pontos medidos da arte."""
    t2 = t * t
    t3 = t2 * t
    return 0.5 * (
        2 * p1
        + (-p0 + p2) * t
        + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
        + (-p0 + 3 * p1 - 3 * p2 + p3) * t3
    )


def calcular_limites_aneis(y):
    """Retorna as quatro bordas curvas da pista na altura informada."""
    if y <= ROTA_ANEIS[0][0]:
        atual, seguinte = ROTA_ANEIS[0], ROTA_ANEIS[1]
        t = (y - atual[0]) / (seguinte[0] - atual[0])
        return tuple(atual[i] + (seguinte[i] - atual[i]) * t for i in range(1, 5))

    if y >= ROTA_ANEIS[-1][0]:
        anterior, atual = ROTA_ANEIS[-2], ROTA_ANEIS[-1]
        t = (y - atual[0]) / (atual[0] - anterior[0])
        return tuple(atual[i] + (atual[i] - anterior[i]) * t for i in range(1, 5))

    for indice in range(len(ROTA_ANEIS) - 1):
        ponto_1 = ROTA_ANEIS[indice]
        ponto_2 = ROTA_ANEIS[indice + 1]
        if ponto_1[0] <= y <= ponto_2[0]:
            ponto_0 = ROTA_ANEIS[indice - 1] if indice > 0 else ponto_1
            ponto_3 = ROTA_ANEIS[indice + 2] if indice + 2 < len(ROTA_ANEIS) else ponto_2
            t = (y - ponto_1[0]) / (ponto_2[0] - ponto_1[0])
            return tuple(
                _catmull_rom(ponto_0[i], ponto_1[i], ponto_2[i], ponto_3[i], t)
                for i in range(1, 5)
            )

    return tuple(ROTA_ANEIS[-1][1:])


def calcular_posicao_pista(progresso_y, lane_ratio=0.50):
    """Posiciona um objeto dentro das quatro bordas curvas dos anéis."""
    y = HORIZON_Y + progresso_y * (BASE_Y - HORIZON_Y + 120)
    limites = calcular_limites_aneis(y)

    posicao_transversal = max(0.0, min(1.0, lane_ratio)) * 3.0
    trecho = min(2, int(posicao_transversal))
    fracao = posicao_transversal - trecho
    x = limites[trecho] + (limites[trecho + 1] - limites[trecho]) * fracao

    # A escala deixa de crescer antes do fim da lane. No plano da vaca ela
    # continua igual, mas não explode de tamanho enquanto sai pela tela.
    t_escala = min(0.92, max(0.0, progresso_y))
    profundidade_escala = t_escala ** 1.3
    tamanho = int(
        TAMANHO_OBSTACULO_MIN
        + (TAMANHO_OBSTACULO_MAX - TAMANHO_OBSTACULO_MIN) * profundidade_escala
    )
    if tamanho < TAMANHO_OBSTACULO_MIN:
        tamanho = TAMANHO_OBSTACULO_MIN

    return x, y, tamanho


def criar_obstaculo(velocidade_base=1.0):
    """Gera obstaculo para desviar de faixa, pular ou agachar."""
    lane_idx = random.randrange(NUM_LANES)
    sorteio_tipo = random.random()
    if sorteio_tipo < 0.22:
        tipo = 'bloqueio'
    elif sorteio_tipo < 0.50:
        tipo = 'alto'
    else:
        tipo = 'chao'
    return {
        'tipo': tipo,
        'lane_idx': lane_idx,
        'lane': LANE_RATIOS[lane_idx],
        'progresso_y': PROGRESSO_SPAWN,
        'velocidade': random.uniform(0.010, 0.016) * velocidade_base,
    }


def carregar_assets_obstaculos():
    """Carrega os tres desafios novos e mantem os assets antigos como fallback."""
    return {
        'bloqueio': carregar_asset([
            "Imagens/ob1.png",
            "Imagens/obstaculos/caixa_energia.png",
            "caixa.png",
        ], com_alpha=True),
        'chao': carregar_asset([
            "Imagens/ob2.png",
            "Imagens/obstaculos/caixa_energia.png",
            "caixa.png",
        ], com_alpha=True),
        'alto': carregar_asset([
            "Imagens/ob3.png",
            "Imagens/obstaculos/portal_agachar.png",
            "p_atras.png",
        ], com_alpha=True),
    }


def calcular_rect_obstaculo(obs):
    """Retorna o retangulo visual do sprite respeitando a perspectiva."""
    cx, cy, tamanho = calcular_posicao_pista(obs['progresso_y'], obs['lane'])
    # ob1/ob2/ob3 compartilham um canvas de 209x385. Manter essa proporcao
    # faz a copa alta e o obstaculo baixo continuarem alinhados no mesmo plano.
    altura = max(24, int(tamanho * 3.80))
    largura = max(12, int(altura * (209 / 385)))
    rect = pygame.Rect(0, 0, largura, altura)
    rect.midbottom = (int(cx), int(cy))
    return rect, cx, cy, tamanho


def calcular_hitbox_obstaculo(obs):
    """Hitboxes alinhadas aos recortes baixo, alto ou de faixa bloqueada."""
    rect, _, _, _ = calcular_rect_obstaculo(obs)
    if obs['tipo'] == 'chao':
        return pygame.Rect(
            rect.x + rect.width * 0.16,
            rect.y + rect.height * 0.45,
            rect.width * 0.68,
            rect.height * 0.50,
        )

    if obs['tipo'] == 'alto':
        # A copa do ob3 ocupa a metade superior e deixa passagem para a vaca baixa.
        return pygame.Rect(
            rect.x + rect.width * 0.06,
            rect.y + rect.height * 0.10,
            rect.width * 0.88,
            rect.height * 0.52,
        )

    # ob1 fecha a faixa da copa ate a base: pular ou agachar nao basta.
    return pygame.Rect(
        rect.x + rect.width * 0.10,
        rect.y + rect.height * 0.02,
        rect.width * 0.80,
        rect.height * 0.93,
    )


def desenhar_guias_faixas(canvas):
    """Desenha três trajetórias tracejadas acompanhando a curva dos anéis."""
    overlay = pygame.Surface((LARGURA_VIRTUAL, ALTURA_VIRTUAL), pygame.SRCALPHA)
    progresso_inicial = PROGRESSO_MINIMO_VISIVEL
    progresso_final = 1.02
    passos = 40

    def ponto(indice, ratio):
        progresso = progresso_inicial + (progresso_final - progresso_inicial) * indice / passos
        return calcular_posicao_pista(progresso, ratio)

    for ratio in LANE_RATIOS:
        for i in range(0, passos, 2):
            p1 = ponto(i, ratio)
            p2 = ponto(i + 1, ratio)
            largura = max(1, int(1 + i / passos * 2))
            pygame.draw.line(overlay, (80, 225, 255, 105), p1[:2], p2[:2], largura)

    canvas.blit(overlay, (0, 0))


def desenhar_obstaculo(canvas, obs, imagens_obstaculos):
    """Renderiza o sprite novo correspondente ao desafio."""
    rect, _, _, tamanho = calcular_rect_obstaculo(obs)
    imagem = imagens_obstaculos[obs['tipo']]

    if obs['tipo'] == 'chao':
        sombra = pygame.Surface((rect.width, max(4, int(tamanho * 0.25))), pygame.SRCALPHA)
        pygame.draw.ellipse(sombra, (5, 8, 18, 115), sombra.get_rect())
        canvas.blit(sombra, (rect.x, rect.bottom - sombra.get_height() // 2))

    sprite = pygame.transform.smoothscale(imagem, rect.size)
    canvas.blit(sprite, rect)


def desenhar_icone_dificuldade(canvas, dificuldade, centro, tamanho=18):
    """Desenha o planeta verde que identifica o modo fácil único."""
    cx, cy = centro
    cor = DIFICULDADES[dificuldade]["cor"]
    contorno = (35, 40, 58)

    pygame.draw.circle(canvas, contorno, (cx, cy), tamanho + 2)
    pygame.draw.circle(canvas, cor, (cx, cy), tamanho)
    pygame.draw.circle(canvas, (36, 145, 112), (cx - 6, cy - 4), max(3, tamanho // 4))
    pygame.draw.circle(canvas, (170, 255, 205), (cx + 5, cy + 5), max(2, tamanho // 5))


def desenhar_ranking(canvas, ranking, destaque_posicao=None):
    """Preenche o quadro de ranking que ja faz parte da arte do menu."""
    fonte_nome = pygame.font.SysFont("Arial", 19, bold=True)
    fonte_pontos = pygame.font.SysFont("Arial", 18, bold=True)
    fonte_vazio = pygame.font.SysFont("Arial", 17, italic=True)
    cores_medalha = [(255, 199, 62), (190, 205, 220), (206, 132, 80)]

    painel = pygame.Rect(758, 151, 300, 458)
    for indice in range(ranking.limite):
        y = painel.y + indice * 82
        preenchimento = (255, 250, 205, 205) if destaque_posicao == indice + 1 else (245, 247, 250, 178)
        linha = pygame.Surface((painel.width, 68), pygame.SRCALPHA)
        linha.fill(preenchimento)
        pygame.draw.rect(linha, (95, 104, 118, 210), linha.get_rect(), 2, border_radius=7)
        canvas.blit(linha, (painel.x, y))

        medalha_cor = cores_medalha[indice] if indice < 3 else (135, 145, 160)
        pygame.draw.circle(canvas, (70, 75, 86), (painel.x + 26, y + 34), 20)
        pygame.draw.circle(canvas, medalha_cor, (painel.x + 26, y + 34), 16)
        numero = fonte_pontos.render(str(indice + 1), True, (38, 42, 52))
        canvas.blit(numero, numero.get_rect(center=(painel.x + 26, y + 34)))

        if indice < len(ranking.entradas):
            entrada = ranking.entradas[indice]
            nome = fonte_nome.render(entrada["nome"], True, (35, 40, 52))
            pontos = fonte_pontos.render(f'{entrada["pontos"]} PTS', True, (45, 50, 62))
            nivel = DIFICULDADES[entrada["dificuldade"]]
            modo = pygame.font.SysFont("Arial", 12, bold=True).render(
                nivel["nome"], True, nivel["cor"]
            )
            canvas.blit(nome, (painel.x + 56, y + 10))
            canvas.blit(pontos, (painel.right - pontos.get_width() - 12, y + 35))
            modo_bg = pygame.Rect(painel.x + 56, y + 39, modo.get_width() + 12, 20)
            pygame.draw.rect(canvas, (50, 55, 68), modo_bg, border_radius=9)
            canvas.blit(modo, (modo_bg.x + 6, modo_bg.y + 3))
        else:
            vazio = fonte_vazio.render("ESPAÇO LIVRE", True, (118, 124, 136))
            canvas.blit(vazio, (painel.x + 60, y + 24))


def desenhar_modo_facil(canvas):
    fonte_opcao = pygame.font.SysFont("Arial", 15, bold=True)
    fonte_detalhe = pygame.font.SysFont("Arial", 12)
    rect = pygame.Rect(30, 285, 190, 56)
    cor = DIFICULDADES[MODO_JOGO]["cor"]
    pygame.draw.rect(canvas, (24, 36, 52), rect, border_radius=9)
    pygame.draw.rect(canvas, cor, rect, 2, border_radius=9)
    desenhar_icone_dificuldade(canvas, MODO_JOGO, (rect.x + 27, rect.centery), 12)
    texto = fonte_opcao.render("MODO FÁCIL", True, cor)
    detalhe = fonte_detalhe.render("velocidade estável", True, (190, 210, 225))
    canvas.blit(texto, (rect.x + 49, rect.y + 9))
    canvas.blit(detalhe, (rect.x + 49, rect.y + 31))


def desenhar_indicador_sensor(canvas, posicao, ativo):
    """Desenha uma pequena cinta/sensor com ondas de conexao."""
    x, y = posicao
    cor = (75, 255, 145) if ativo else (145, 155, 175)
    pygame.draw.rect(canvas, (28, 34, 48), (x, y + 7, 28, 14), border_radius=5)
    pygame.draw.rect(canvas, cor, (x + 8, y + 3, 12, 22), 2, border_radius=3)
    if ativo:
        pygame.draw.arc(canvas, cor, (x + 24, y + 3, 18, 20), -1.0, 1.0, 2)
        pygame.draw.arc(canvas, cor, (x + 27, y, 25, 26), -1.0, 1.0, 2)


# =========================================================
# CLASSE DA VACA (PLAYER COM SISTEMA DE PULO)
# =========================================================
class VacaPlayer:
    def __init__(self, frames_andar, frames_agachar):
        self.frames_andar = frames_andar
        self.frames_agachar = frames_agachar

        # Comeca na faixa central e desliza suavemente entre as tres faixas.
        self.current_lane = 1
        self.target_x = self._calcular_x_da_faixa(self.current_lane)
        self.x = self.target_x
        self.y_base = BASE_Y
        self.is_moving = False

        # Física de Salto (Pulo)
        self.is_jumping = False
        self.jump_y = 0.0          # Deslocamento vertical negativo no ar
        self.vel_y = 0.0           # Velocidade vertical
        self.gravidade = 0.95      # Gravidade do pulo
        self.forca_pulo = -18.0    # Força inicial do salto
        self.is_crouching = False

        self.frame_index = 0.0
        self.anim_speed = 0.22

    def _calcular_x_da_faixa(self, lane_idx):
        cx, _, _ = calcular_posicao_pista(PROGRESSO_PLANO_VACA, LANE_RATIOS[lane_idx])
        return cx - (LARGURA_VACA_NORMAL / 2.0)

    def update(self, input_ctrl):
        # 1. Camera envia a faixa absoluta; teclado continua como fallback.
        target_lane, shift = input_ctrl.consume_lane_commands()
        if target_lane is not None:
            self.current_lane = target_lane
        elif shift:
            self.current_lane = max(0, min(NUM_LANES - 1, self.current_lane + shift))
        self.target_x = self._calcular_x_da_faixa(self.current_lane)

        diff_x = self.target_x - self.x
        if abs(diff_x) > 1.2:
            self.x += diff_x * 0.26
            self.is_moving = True
        else:
            self.x = self.target_x
            self.is_moving = False

        # 2. Trata comando de PULO
        if input_ctrl.consume_jump() and not self.is_jumping:
            self.is_jumping = True
            self.vel_y = self.forca_pulo

        # 3. Física do Pulo no ar
        if self.is_jumping:
            self.jump_y += self.vel_y
            self.vel_y += self.gravidade
            # Aterrissagem no chão
            if self.jump_y >= 0.0:
                self.jump_y = 0.0
                self.is_jumping = False
                self.vel_y = 0.0

        # Agachamento e pulo sao mutuamente exclusivos na representacao.
        self.is_crouching = input_ctrl.is_crouching and not self.is_jumping

        # 4. Controle de animação
        self.frame_index = (self.frame_index + self.anim_speed) % len(self.frames_andar)

    def get_hitbox(self):
        """Retorna a hitbox ajustada para o pulo."""
        if self.is_jumping:
            # Hitbox no ar (deslocada para cima pelo jump_y)
            hb_w = LARGURA_VACA_NORMAL * 0.60
            hb_h = ALTURA_VACA_NORMAL * 0.65
            hb_x = self.x + (LARGURA_VACA_NORMAL - hb_w) / 2
            hb_y = self.y_base - ALTURA_VACA_NORMAL + 20 + self.jump_y
            return pygame.Rect(hb_x, hb_y, hb_w, hb_h)
        elif self.is_crouching:
            hb_w = LARGURA_VACA_AGACHADA * 0.68
            hb_h = ALTURA_VACA_AGACHADA * 0.58
            hb_x = self.x + (LARGURA_VACA_AGACHADA - hb_w) / 2
            hb_y = self.y_base - hb_h
            return pygame.Rect(hb_x, hb_y, hb_w, hb_h)
        else:
            # Hitbox normal em pé
            hb_w = LARGURA_VACA_NORMAL * 0.60
            hb_h = ALTURA_VACA_NORMAL * 0.75
            hb_x = self.x + (LARGURA_VACA_NORMAL - hb_w) / 2
            hb_y = self.y_base - hb_h
            return pygame.Rect(hb_x, hb_y, hb_w, hb_h)

    def draw(self, surface):
        # 1. Sombra no chão (diminui de tamanho quando a vaca pula alto)
        shadow_w = int(LARGURA_VACA_NORMAL * 0.75 * max(0.35, 1.0 - abs(self.jump_y) / 200.0))
        shadow_h = 16
        shadow_x = int(self.x + LARGURA_VACA_NORMAL / 2 - shadow_w / 2)
        shadow_y = int(self.y_base - 8)
        shadow_surf = pygame.Surface((shadow_w, shadow_h), pygame.SRCALPHA)
        shadow_alpha = int(140 * max(0.2, 1.0 - abs(self.jump_y) / 220.0))
        pygame.draw.ellipse(shadow_surf, (15, 15, 25, shadow_alpha), (0, 0, shadow_w, shadow_h))
        surface.blit(shadow_surf, (shadow_x, shadow_y))

        # 2. Desenho do Sprite da Vaca
        idx = int(self.frame_index) % 3
        if self.is_jumping:
            # Pose de salto no ar
            img = self.frames_andar[1]
            surface.blit(img, (self.x, self.y_base - ALTURA_VACA_NORMAL + self.jump_y))
        elif self.is_crouching:
            img = self.frames_agachar[idx]
            surface.blit(img, (self.x, self.y_base - img.get_height()))
        else:
            # Pose normal correndo
            img = self.frames_andar[idx]
            surface.blit(img, (self.x, self.y_base - ALTURA_VACA_NORMAL))


# =========================================================
# TELA CHEIA E GERENCIAMENTO DE RESOLUÇÃO (LETTERBOXING)
# =========================================================
class DisplayManager:
    """Gerencia a janela com proporção 16:9 perfeita em qualquer monitor."""
    def __init__(self):
        self.is_fullscreen = False
        self.real_screen = pygame.display.set_mode((LARGURA_VIRTUAL, ALTURA_VIRTUAL), pygame.RESIZABLE)
        pygame.display.set_caption("Cow Abduct - Visao Computacional (IFFar)")
        self.virtual_screen = pygame.Surface((LARGURA_VIRTUAL, ALTURA_VIRTUAL))

    def toggle_fullscreen(self):
        self.is_fullscreen = not self.is_fullscreen
        if self.is_fullscreen:
            self.real_screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.real_screen = pygame.display.set_mode((LARGURA_VIRTUAL, ALTURA_VIRTUAL), pygame.RESIZABLE)

    def render(self):
        janela_w, janela_h = self.real_screen.get_size()
        escala = min(janela_w / LARGURA_VIRTUAL, janela_h / ALTURA_VIRTUAL)
        novo_w = int(LARGURA_VIRTUAL * escala)
        novo_h = int(ALTURA_VIRTUAL * escala)
        offset_x = (janela_w - novo_w) // 2
        offset_y = (janela_h - novo_h) // 2

        self.real_screen.fill((0, 0, 0))
        scaled = pygame.transform.smoothscale(self.virtual_screen, (novo_w, novo_h))
        self.real_screen.blit(scaled, (offset_x, offset_y))
        pygame.display.flip()

    def map_mouse_pos(self, mouse_pos):
        janela_w, janela_h = self.real_screen.get_size()
        escala = min(janela_w / LARGURA_VIRTUAL, janela_h / ALTURA_VIRTUAL)
        novo_w = int(LARGURA_VIRTUAL * escala)
        novo_h = int(ALTURA_VIRTUAL * escala)
        offset_x = (janela_w - novo_w) // 2
        offset_y = (janela_h - novo_h) // 2

        vx = (mouse_pos[0] - offset_x) / escala
        vy = (mouse_pos[1] - offset_y) / escala
        return vx, vy


# =========================================================
# TABELA / PAINEL DE DEBUG EM TEMPO REAL
# =========================================================
def desenhar_tabela_debug(canvas, input_ctrl, vision_ctrl, vaca=None, fps=60.0):
    """Renderiza telemetria da camera, do cubo ESP32 e do player."""
    if not input_ctrl.show_debug:
        return

    painel_w, painel_h = 455, 410
    painel_x = LARGURA_VIRTUAL - painel_w - 20
    painel_y = 20

    painel_bg = pygame.Surface((painel_w, painel_h), pygame.SRCALPHA)
    painel_bg.fill((12, 16, 28, 230))
    pygame.draw.rect(painel_bg, (0, 180, 255), (0, 0, painel_w, painel_h), 2, border_radius=8)
    canvas.blit(painel_bg, (painel_x, painel_y))

    fonte_tit = pygame.font.SysFont("Courier New", 14, bold=True)
    fonte_txt = pygame.font.SysFont("Courier New", 13, bold=True)
    txt_tit = fonte_tit.render("== VISAO COMPUTACIONAL / CUBO ESP32 ==", True, (255, 220, 80))
    canvas.blit(txt_tit, (painel_x + 15, painel_y + 10))
    pygame.draw.line(canvas, (0, 180, 255), (painel_x + 10, painel_y + 30), (painel_x + painel_w - 10, painel_y + 30), 1)

    camera_cor = (80, 255, 120) if vision_ctrl.connected and vision_ctrl.pose_visible else (255, 190, 80)
    esp_cor = (80, 255, 120) if input_ctrl.esp32_connected else (150, 160, 180)
    esp_status = input_ctrl.active_port_name if input_ctrl.esp32_connected else "aguardando cubo"

    face = input_ctrl.cube_face
    if face in CUBE_FACE_POWERS:
        cube_name = f'{face} / {CUBE_FACE_POWERS[face]["name"]}'
        cube_cor = CUBE_FACE_POWERS[face]["color"]
    elif input_ctrl.cube_candidate_face:
        cube_name = f"estabilizando {input_ctrl.cube_candidate_face}"
        cube_cor = (255, 210, 90)
    else:
        cube_name = "MOVENDO / SEM FACE"
        cube_cor = esp_cor

    if vaca:
        if vaca.is_jumping:
            acao_str, acao_cor = "PULANDO NO AR", (100, 230, 255)
        elif vaca.is_crouching:
            acao_str, acao_cor = "AGACHADO", (255, 220, 80)
        else:
            acao_str, acao_cor = "CORRENDO NA PISTA", (80, 255, 120)
        lane_nome = NOME_LANES[vaca.current_lane]
    else:
        acao_str, acao_cor = "MENU INICIAL", (180, 180, 180)
        lane_nome = "CENTRO"

    linhas = [
        ("Camera:", vision_ctrl.status[:34], camera_cor),
        ("Detector:", vision_ctrl.engine, (100, 230, 255)),
        ("Gesto lido:", vision_ctrl.action, acao_cor),
        ("Mov. lateral:", f"{vision_ctrl.lateral:+.2f} troncos", (100, 230, 255)),
        ("Mov. vertical:", f"{vision_ctrl.vertical:+.2f} troncos", (255, 200, 80)),
        ("Faixa da vaca:", lane_nome, (255, 255, 100)),
        ("Estado da vaca:", acao_str, acao_cor),
        ("Ultima entrada:", input_ctrl.last_control_source.upper(), (200, 220, 255)),
        ("ESP32:", esp_status[:30], esp_cor),
        ("Acelerometro:", f"{input_ctrl.raw_ax:+.2f} {input_ctrl.raw_ay:+.2f} {input_ctrl.raw_az:+.2f}", (120, 235, 255)),
        ("Face / poder:", cube_name, cube_cor),
        ("Estabilidade:", f"{input_ctrl.cube_stability * 100:3.0f}%", cube_cor),
        ("FPS jogo/camera:", f"{fps:.0f} / {vision_ctrl.fps:.0f}", (180, 220, 255)),
    ]

    curr_y = painel_y + 38
    for label, val, cor in linhas:
        t_lbl = fonte_txt.render(label, True, (160, 180, 210))
        t_val = fonte_txt.render(val, True, cor)
        canvas.blit(t_lbl, (painel_x + 15, curr_y))
        canvas.blit(t_val, (painel_x + 160, curr_y))
        curr_y += 24

    t_dica = fonte_tit.render("[C] Recalibrar | [V] Camera | [TAB] Painel", True, (120, 145, 175))
    canvas.blit(t_dica, (painel_x + 15, painel_y + painel_h - 22))

    if time.time() < input_ctrl.feedback_timer and input_ctrl.feedback_msg:
        fonte_pop = pygame.font.SysFont("Arial", 22, bold=True)
        t_pop = fonte_pop.render(input_ctrl.feedback_msg, True, (255, 255, 100))
        pop_w = t_pop.get_width() + 30
        pop_h = 44
        pop_x = (LARGURA_VIRTUAL - pop_w) // 2
        pop_y = 35
        pop_bg = pygame.Surface((pop_w, pop_h), pygame.SRCALPHA)
        pop_bg.fill((20, 30, 50, 235))
        pygame.draw.rect(pop_bg, (0, 220, 255), (0, 0, pop_w, pop_h), 2, border_radius=8)
        canvas.blit(pop_bg, (pop_x, pop_y))
        canvas.blit(t_pop, (pop_x + 15, pop_y + 8))


def desenhar_painel_cubo(canvas, input_ctrl, powers=None):
    """Mostra a face reconhecida e os efeitos sem exigir o painel de debug."""
    if input_ctrl.show_debug:
        return

    rect = pygame.Rect(LARGURA_VIRTUAL - 385, 20, 365, 105)
    painel = pygame.Surface(rect.size, pygame.SRCALPHA)
    painel.fill((12, 18, 31, 218))

    conectado = input_ctrl.esp32_connected
    cor = (80, 255, 135) if conectado else (135, 150, 175)
    face = input_ctrl.cube_face
    if powers is not None and powers.armed:
        cor = (90, 245, 145)
        if input_ctrl.cube_candidate_face and input_ctrl.cube_stability < 1.0:
            titulo_face = f"CUBO PRONTO: ESTABILIZANDO {input_ctrl.cube_candidate_face}"
        else:
            titulo_face = "CUBO PRONTO: GIRE PARA OUTRA FACE"
    elif powers is not None:
        titulo_face = f"CUBO CARREGANDO: {powers.charge}/{powers.required_obstacles}"
        cor = (80, 190, 255) if conectado else cor
    elif face in CUBE_FACE_POWERS:
        config = CUBE_FACE_POWERS[face]
        cor = config["color"]
        titulo_face = f'CUBO {face}: {config["name"]}'
    elif input_ctrl.cube_candidate_face:
        titulo_face = f"ESTABILIZANDO {input_ctrl.cube_candidate_face}..."
        cor = (255, 210, 90)
    elif conectado:
        titulo_face = "GIRE E APOIE UMA FACE"
    else:
        titulo_face = "AGUARDANDO ESP32"

    pygame.draw.rect(painel, cor, painel.get_rect(), 2, border_radius=9)
    fonte_titulo = pygame.font.SysFont("Arial", 18, bold=True)
    fonte_texto = pygame.font.SysFont("Arial", 14, bold=True)
    fonte_dica = pygame.font.SysFont("Arial", 12)
    painel.blit(fonte_titulo.render(titulo_face, True, cor), (14, 10))

    if powers is not None:
        barra = pygame.Rect(14, 40, 337, 10)
        pygame.draw.rect(painel, (45, 54, 72), barra, border_radius=5)
        preenchida = barra.copy()
        preenchida.width = int(barra.width * powers.charge_ratio)
        pygame.draw.rect(painel, cor, preenchida, border_radius=5)
        ativos = powers.active_effects()
        dica = "ATIVOS: " + ("  |  ".join(ativos) if ativos else "nenhum")
    elif input_ctrl.cube_candidate_face and input_ctrl.cube_stability < 1.0:
        barra = pygame.Rect(14, 40, 337, 10)
        pygame.draw.rect(painel, (45, 54, 72), barra, border_radius=5)
        preenchida = barra.copy()
        preenchida.width = int(barra.width * input_ctrl.cube_stability)
        pygame.draw.rect(painel, cor, preenchida, border_radius=5)
        dica = "Mantenha o modulo parado por meio segundo"
    else:
        dica = "Cada orientacao seleciona um poder diferente"

    face_curta = face or "--"
    vetor = f"FACE {face_curta} | X {input_ctrl.raw_ax:+.2f}  Y {input_ctrl.raw_ay:+.2f}  Z {input_ctrl.raw_az:+.2f} G"
    painel.blit(fonte_texto.render(vetor, True, (205, 225, 245)), (14, 58))
    painel.blit(fonte_dica.render(dica, True, (175, 195, 220)), (14, 82))
    canvas.blit(painel, rect.topleft)


def desenhar_alerta_poder_cubo(canvas, powers, now):
    """Exibe uma confirmacao grande quando um poder e disparado."""
    if now >= powers.message_until or not powers.last_message:
        return

    fonte = pygame.font.SysFont("Arial", 22, bold=True)
    texto = fonte.render(powers.last_message, True, powers.last_color)
    rect = texto.get_rect()
    rect.inflate_ip(34, 22)
    rect.midtop = (LARGURA_VIRTUAL // 2, 28)
    fundo = pygame.Surface(rect.size, pygame.SRCALPHA)
    fundo.fill((18, 24, 40, 235))
    pygame.draw.rect(fundo, powers.last_color, fundo.get_rect(), 2, border_radius=10)
    canvas.blit(fundo, rect.topleft)
    canvas.blit(texto, texto.get_rect(center=rect.center))


def desenhar_preview_camera(canvas, input_ctrl, vision_ctrl, posicao=(20, 445), tamanho=None):
    """Mostra a camera dentro do jogo, sem abrir uma segunda janela."""
    if not input_ctrl.show_camera:
        return

    preview = vision_ctrl.get_preview()
    x, y = posicao
    width, height = tamanho or vision_ctrl.PREVIEW_SIZE
    pygame.draw.rect(canvas, (10, 16, 28), (x - 5, y - 31, width + 10, height + 36), border_radius=8)
    pygame.draw.rect(canvas, (0, 210, 255), (x - 5, y - 31, width + 10, height + 36), 2, border_radius=8)

    fonte = pygame.font.SysFont("Arial", 16, bold=True)
    titulo = fonte.render("CAMERA IA  |  [V] ocultar", True, (220, 245, 255))
    canvas.blit(titulo, (x + 5, y - 25))

    if preview:
        frame_bytes, size = preview
        surface = pygame.image.frombuffer(frame_bytes, size, "RGB")
        if surface.get_size() != (width, height):
            surface = pygame.transform.smoothscale(surface, (width, height))
        canvas.blit(surface, (x, y))
    else:
        pygame.draw.rect(canvas, (22, 28, 42), (x, y, width, height))
        mensagem = fonte.render(vision_ctrl.status[:35], True, (255, 210, 100))
        canvas.blit(mensagem, (x + 12, y + height // 2 - 8))


# =========================================================
# TELA INICIAL
# =========================================================
def tela_inicial(
    display_mgr,
    input_ctrl,
    vision_ctrl,
    ranking,
    nome_jogador="JOGADOR",
):
    fundo = carregar_asset([
        "Imagens/fundo_inicio.gif",
        "Imagens/fundo_inicio1.jpg",
        "Imagens/fundo_jogo/caminho.png",
    ])
    fundo = pygame.transform.scale(fundo, (LARGURA_VIRTUAL, ALTURA_VIRTUAL))

    # O botão cinza já faz parte da arte do menu; só criamos sua área clicável.
    botao_rect = pygame.Rect(AREA_BOTAO_JOGAR)

    fonte_dica = pygame.font.SysFont("Arial", 22, bold=True)
    fonte_ctrl = pygame.font.SysFont("Arial", 20)
    fonte_nome = pygame.font.SysFont("Arial", 18, bold=True)
    fonte_nome_label = pygame.font.SysFont("Arial", 13, bold=True)
    fonte_nome_dica = pygame.font.SysFont("Arial", 11)
    clock = pygame.time.Clock()
    nome_digitado = normalizar_nome_jogador(nome_jogador)
    editando_nome = False
    nome_rect = pygame.Rect(30, 363, 190, 48)

    esperando = True
    while esperando:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN and editando_nome:
                if event.key == pygame.K_RETURN:
                    editando_nome = False
                elif event.key == pygame.K_ESCAPE:
                    editando_nome = False
                elif event.key == pygame.K_BACKSPACE:
                    nome_digitado = nome_digitado[:-1]
                elif event.unicode and event.unicode.isprintable() and len(nome_digitado) < 12:
                    candidato = normalizar_nome_jogador(nome_digitado + event.unicode)
                    nome_digitado = "" if candidato == "JOGADOR" and not nome_digitado and event.unicode.isspace() else candidato
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_f or event.key == pygame.K_F11:
                    display_mgr.toggle_fullscreen()
                elif event.key == pygame.K_TAB:
                    input_ctrl.show_debug = not input_ctrl.show_debug
                elif event.key == pygame.K_v:
                    input_ctrl.show_camera = not input_ctrl.show_camera
                elif event.key == pygame.K_c:
                    input_ctrl.calibrate_center()
                elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    esperando = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                vx, vy = display_mgr.map_mouse_pos(event.pos)
                if botao_rect.collidepoint((vx, vy)):
                    esperando = False
                elif nome_rect.collidepoint((vx, vy)):
                    editando_nome = True
                    if nome_digitado == "JOGADOR":
                        nome_digitado = ""
                else:
                    editando_nome = False

        # Renderiza no canvas virtual
        display_mgr.virtual_screen.blit(fundo, (0, 0))

        desenhar_ranking(display_mgr.virtual_screen, ranking)
        desenhar_modo_facil(display_mgr.virtual_screen)

        mouse_virtual = display_mgr.map_mouse_pos(pygame.mouse.get_pos())
        if botao_rect.collidepoint(mouse_virtual):
            pygame.draw.rect(
                display_mgr.virtual_screen,
                (130, 255, 185),
                botao_rect.inflate(8, 8),
                2,
                border_radius=5,
            )

        nome_bg = pygame.Surface(nome_rect.size, pygame.SRCALPHA)
        nome_bg.fill((25, 35, 52, 225))
        display_mgr.virtual_screen.blit(nome_bg, nome_rect)
        pygame.draw.rect(
            display_mgr.virtual_screen,
            (80, 225, 255) if editando_nome else (115, 135, 158),
            nome_rect,
            2,
            border_radius=8,
        )
        cursor = "_" if editando_nome and int(time.time() * 2) % 2 == 0 else ""
        nome_exibido = nome_digitado or "DIGITE SEU NOME"
        label_nome = fonte_nome_label.render("JOGADOR", True, (185, 205, 225))
        display_mgr.virtual_screen.blit(label_nome, (nome_rect.x + 4, nome_rect.y - 18))
        txt_nome = fonte_nome.render(f"{nome_exibido}{cursor}", True, (238, 246, 255))
        display_mgr.virtual_screen.blit(txt_nome, (nome_rect.x + 12, nome_rect.y + 8))
        txt_nome_dica = fonte_nome_dica.render("clique para editar", True, (170, 194, 215))
        display_mgr.virtual_screen.blit(txt_nome_dica, (nome_rect.x + 12, nome_rect.bottom - 14))

        txt_dica = fonte_dica.render("Clique em JOGAR ou [ESPAÇO]  |  [F] Tela Cheia", True, (240, 240, 240))
        display_mgr.virtual_screen.blit(txt_dica, (LARGURA_VIRTUAL // 2 - txt_dica.get_width() // 2, ALTURA_VIRTUAL - 55))

        txt_inst = fonte_ctrl.render("Corpo: lados = faixas | subir = pular | baixar = agachar | [C] recalibrar", True, (255, 230, 100))
        display_mgr.virtual_screen.blit(txt_inst, (LARGURA_VIRTUAL // 2 - txt_inst.get_width() // 2, ALTURA_VIRTUAL - 26))

        # A camera e o esqueleto sao o controle principal; teclado e ESP32 sao fallback.
        if vision_ctrl.connected and vision_ctrl.pose_visible:
            badge_txt = fonte_dica.render("● CAMERA IA ATIVA", True, (80, 255, 120))
        else:
            badge_txt = fonte_dica.render(f"○ {vision_ctrl.status}", True, (255, 210, 100))
        display_mgr.virtual_screen.blit(badge_txt, (30, 30))

        # A camera fica em miniatura para liberar o quadro original do ranking.
        desenhar_preview_camera(
            display_mgr.virtual_screen,
            input_ctrl,
            vision_ctrl,
            posicao=(20, 105),
            tamanho=(210, 158),
        )
        desenhar_painel_cubo(display_mgr.virtual_screen, input_ctrl)
        desenhar_tabela_debug(display_mgr.virtual_screen, input_ctrl, vision_ctrl, None, clock.get_fps())

        display_mgr.render()
        clock.tick(FPS)

    return normalizar_nome_jogador(nome_digitado)


# =========================================================
# LOOP PRINCIPAL DA GAMEPLAY (PULAR E ABAIXAR)
# =========================================================
def loop_gameplay(
    display_mgr,
    input_ctrl,
    vision_ctrl,
    frames_andar,
    frames_agachar,
    fundo_cenario,
    imagens_obstaculos,
    ranking,
    nome_jogador,
):
    fonte_hud = pygame.font.SysFont("Arial", 28, bold=True)
    fonte_hud_status = pygame.font.SysFont("Arial", 16, bold=True)
    fonte_go_grande = pygame.font.SysFont("Arial", 64, bold=True)
    fonte_go_sub = pygame.font.SysFont("Arial", 26)
    fonte_alerta = pygame.font.SysFont("Arial", 20, bold=True)
    clock = pygame.time.Clock()
    config_dificuldade = DIFICULDADES[MODO_JOGO]

    while True:
        vaca = VacaPlayer(frames_andar, frames_agachar)
        powers = CubePowerSystem()
        # Nao carrega para uma nova partida entradas feitas no menu/game over.
        input_ctrl.consume_jump()
        input_ctrl.consume_cube_power()
        obstaculos = []

        spawn_timer = 0
        spawn_intervalo = config_dificuldade["spawn"]
        pontuacao = 0.0
        distancia = 0.0
        game_over = False
        posicao_ranking = None

        partida_ativa = True
        while partida_ativa:
            # 1. Trata Eventos
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f or event.key == pygame.K_F11:
                        display_mgr.toggle_fullscreen()
                    elif event.key == pygame.K_TAB:
                        input_ctrl.show_debug = not input_ctrl.show_debug
                    elif event.key == pygame.K_v:
                        input_ctrl.show_camera = not input_ctrl.show_camera
                    elif event.key == pygame.K_ESCAPE:
                        return True
                    elif game_over:
                        if event.key in (pygame.K_r, pygame.K_SPACE, pygame.K_RETURN):
                            partida_ativa = False

            # 2. Atualiza Entradas
            keys = pygame.key.get_pressed()
            input_ctrl.update_from_keyboard(keys)

            # 3. Lógica do Jogo
            if not game_over:
                agora = time.monotonic()
                face_ativada = input_ctrl.consume_cube_power()
                if face_ativada is not None and powers.armed:
                    ativacao = powers.activate_face(face_ativada, agora)
                    if ativacao and ativacao.accepted:
                        if ativacao.clear_track:
                            obstaculos.clear()

                velocidade_modo = config_dificuldade["velocidade"]
                distancia += 0.35 * velocidade_modo
                pontuacao += velocidade_modo * powers.score_multiplier(agora)
                spawn_intervalo_atual = (
                    spawn_intervalo * powers.spawn_interval_multiplier(agora)
                )

                # Geração de Obstáculos (Trocar de faixa / Pular / Agachar)
                spawn_timer += 1
                if spawn_timer >= spawn_intervalo_atual:
                    obstaculos.append(criar_obstaculo(
                        velocidade_base=velocidade_modo
                    ))
                    spawn_timer = 0

                # Atualiza Vaca (Pulo / Agacho)
                vaca.update(input_ctrl)
                hitbox_vaca = vaca.get_hitbox()

                # Atualiza Obstáculos ao longo da perspectiva dos anéis
                velocidade_cubo = powers.obstacle_speed_multiplier(agora)
                for obs in obstaculos:
                    obs['progresso_y'] += obs['velocidade'] * velocidade_cubo

                    # Cada obstaculo realmente superado carrega 20% do cubo.
                    if not obs.get('contabilizado_para_cubo'):
                        _, cy, _ = calcular_posicao_pista(
                            obs['progresso_y'], obs['lane']
                        )
                        if cy > BASE_Y + 35:
                            obs['contabilizado_para_cubo'] = True
                            powers.register_obstacle_passed(agora)

                # Remove obstáculos fora da tela
                obstaculos = [o for o in obstaculos if o['progresso_y'] < 1.35]

                # Colide apenas quando a base do obstaculo cruza o plano da vaca.
                for obs in obstaculos:
                    _, cy, _ = calcular_posicao_pista(obs['progresso_y'], obs['lane'])
                    if BASE_Y - 45 <= cy <= BASE_Y + 35:
                        if hitbox_vaca.colliderect(calcular_hitbox_obstaculo(obs)):
                            if powers.absorb_collision(agora):
                                obs['destruido_pelo_cubo'] = True
                                powers.last_message = "COLISAO BLOQUEADA PELO CUBO"
                                powers.last_color = (75, 225, 255)
                                powers.message_until = agora + 1.8
                            else:
                                game_over = True
                                posicao_ranking = ranking.registrar(
                                    nome_jogador,
                                    int(pontuacao),
                                    MODO_JOGO,
                                )
                            break

                obstaculos = [
                    obs for obs in obstaculos
                    if not obs.get('destruido_pelo_cubo')
                ]

            # 4. Renderização no Canvas Virtual
            canvas = display_mgr.virtual_screen
            fundo_cenario.desenhar(canvas)
            desenhar_guias_faixas(canvas)

            # Do horizonte para a camera: os mais proximos cobrem os distantes.
            for obs in sorted(obstaculos, key=lambda item: item['progresso_y']):
                if obs['progresso_y'] > PROGRESSO_MINIMO_VISIVEL:
                    desenhar_obstaculo(canvas, obs, imagens_obstaculos)

            # Desenha a Vaca (com sombra dinâmica e animação de pulo/agacho)
            vaca.draw(canvas)

            # HUD Superior
            hud_bg = pygame.Surface((390, 135), pygame.SRCALPHA)
            hud_bg.fill((20, 20, 35, 190))
            canvas.blit(hud_bg, (20, 20))

            txt_score = fonte_hud.render(f"PONTOS: {int(pontuacao)}", True, (255, 230, 90))
            txt_dist = fonte_hud.render(f"DISTÂNCIA: {int(distancia)}m", True, (255, 255, 255))
            canvas.blit(txt_score, (35, 26))
            canvas.blit(txt_dist, (35, 56))

            if vision_ctrl.connected and vision_ctrl.pose_visible:
                txt_status = fonte_hud_status.render(f"● CAMERA IA: {vision_ctrl.action}", True, (80, 255, 120))
            elif input_ctrl.esp32_connected:
                txt_status = fonte_hud_status.render(f"● ESP32 [{input_ctrl.active_port_name}]", True, (80, 255, 120))
            else:
                txt_status = fonte_hud_status.render("○ FALLBACK: TECLADO (WASD / SETAS)", True, (255, 210, 100))
            canvas.blit(txt_status, (35, 86))

            velocidade_atual = config_dificuldade["velocidade"]
            desenhar_icone_dificuldade(canvas, MODO_JOGO, (48, 126), 12)
            txt_dificuldade = fonte_hud_status.render(
                f'{config_dificuldade["nome"]}  •  VELOCIDADE x{velocidade_atual:.2f}',
                True,
                config_dificuldade["cor"],
            )
            canvas.blit(txt_dificuldade, (68, 117))
            desenhar_indicador_sensor(canvas, (342, 108), input_ctrl.esp32_connected)

            # Alerta de Ação no HUD
            if vaca.is_jumping:
                txt_act = fonte_alerta.render("🚀 SALTO!", True, (100, 230, 255))
                canvas.blit(txt_act, (380, 30))
            elif vaca.is_crouching:
                txt_act = fonte_alerta.render("🛡️ AGACHADO!", True, (255, 220, 80))
                canvas.blit(txt_act, (380, 30))

            desenhar_preview_camera(canvas, input_ctrl, vision_ctrl)
            desenhar_painel_cubo(canvas, input_ctrl, powers)
            desenhar_alerta_poder_cubo(canvas, powers, time.monotonic())
            desenhar_tabela_debug(canvas, input_ctrl, vision_ctrl, vaca, clock.get_fps())

            # Tela de Game Over
            if game_over:
                overlay = pygame.Surface((LARGURA_VIRTUAL, ALTURA_VIRTUAL), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 195))
                canvas.blit(overlay, (0, 0))

                txt_go = fonte_go_grande.render("GAME OVER", True, (255, 60, 60))
                txt_score_final = fonte_hud.render(f"Pontuação Final: {int(pontuacao)}", True, (255, 255, 255))
                txt_sub1 = fonte_go_sub.render("Pressione [R] ou [ESPAÇO] para Jogar Novamente", True, (240, 240, 240))
                txt_sub2 = fonte_go_sub.render("Pressione [ESC] para Voltar ao Menu Inicial", True, (180, 180, 180))

                if posicao_ranking is not None:
                    txt_ranking = fonte_go_sub.render(
                        f"NOVO #{posicao_ranking} DO RANKING!",
                        True,
                        (255, 220, 80),
                    )
                else:
                    txt_ranking = fonte_go_sub.render(
                        "Continue tentando para entrar no TOP 5!",
                        True,
                        (190, 205, 220),
                    )

                canvas.blit(txt_go, (LARGURA_VIRTUAL // 2 - txt_go.get_width() // 2, 220))
                canvas.blit(txt_score_final, (LARGURA_VIRTUAL // 2 - txt_score_final.get_width() // 2, 310))
                canvas.blit(txt_ranking, (LARGURA_VIRTUAL // 2 - txt_ranking.get_width() // 2, 355))
                canvas.blit(txt_sub1, (LARGURA_VIRTUAL // 2 - txt_sub1.get_width() // 2, 415))
                canvas.blit(txt_sub2, (LARGURA_VIRTUAL // 2 - txt_sub2.get_width() // 2, 460))

            display_mgr.render()
            clock.tick(FPS)


# =========================================================
# PONTO DE ENTRADA PRINCIPAL
# =========================================================
def main():
    pygame.init()
    pygame.font.init()

    display_mgr = DisplayManager()

    input_ctrl = InputController()
    vision_ctrl = VisionController(input_ctrl)
    input_ctrl.vision_recalibrate_callback = vision_ctrl.request_calibration
    vision_ctrl.start()
    input_ctrl.start_esp32_connection(port="auto", baudrate=115200)
    ranking = RankingPersistente()
    nome_jogador = "JOGADOR"
    fundo_cenario = None

    try:
        # Carrega cenário do jogo e caixa de obstáculos
        imagem_cenario = carregar_asset([
            "Imagens/fundo_jogo/caminho.png",
            "Imagens/fundo_jogo/caminho1.png",
            "Imagens/caminho.png",
            "Imagens/caminho1.png",
            "Imagens/fundo_jogo/listra.png"
        ])
        fundo_cenario = FundoJogoAnimado(
            VIDEO_FUNDO_JOGO,
            imagem_cenario,
            (LARGURA_VIRTUAL, ALTURA_VIRTUAL),
        )

        imagens_obstaculos = carregar_assets_obstaculos()

        frames_andar, frames_agachar = carregar_sprites_vaca()

        while True:
            nome_jogador = tela_inicial(
                display_mgr,
                input_ctrl,
                vision_ctrl,
                ranking,
                nome_jogador,
            )
            continuar = loop_gameplay(
                display_mgr,
                input_ctrl,
                vision_ctrl,
                frames_andar,
                frames_agachar,
                fundo_cenario,
                imagens_obstaculos,
                ranking,
                nome_jogador,
            )
            if not continuar:
                break
    finally:
        if fundo_cenario is not None:
            fundo_cenario.close()
        vision_ctrl.stop()
        input_ctrl.esp32_running = False
        pygame.quit()


if __name__ == "__main__":
    main()
